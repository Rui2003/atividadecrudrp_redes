<?php
session_start();
if(!isset($_SESSION['login'])){
	$_SESSION['login']="incorreto";
}
if ($_SESSION['login']=="correto" && isset($_SESSION['login'])){
	$con=new mysqli("localhost", "root", "", "filmes");
	if($con->connect_errno!=0){
		echo "Ocorreu um erro no acesso á base de dados " .$con->connect_error;
		exit;
	}
	else {
?>

	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="ISO-8859-1">
		<title>filmes</title>
	</head>
	<body>
	<h1>Lista de filmes</h1>
	<?php
		$stm = $con->prepare('select * from filmes');
		$stm->execute();
		$res=$stm->get_result();
		while($resultado = $res->fetch_assoc()) {
			echo '<br><a href="filmes_show.php?filme='. $resultado['id_filme']. '">';
			echo $resultado['titulo'];
			echo '</a>';
			
			echo '<a href="filmes_edit.php?filme='. $resultado['id_filme']. '">               editar</a>';
			echo '</a>';
			echo '<br>';

			echo '<a href="filmes_delete.php?filme='. $resultado['id_filme']. '"> eliminar</a>';
			echo'<br>';



		}
	$stm->close();
	?>
	<hr>
	<h1>Lista de atores</h1>
	<?php
		$stm = $con->prepare('select * from atores');
		$stm->execute();
		$res=$stm->get_result();
		while($resultado = $res->fetch_assoc()) {
			echo '<a href="ator_show.php?ator='. $resultado['id_ator']. '">';
			echo $resultado['nome'];
			echo '</a>';
			
			echo '<a href="ator_edit.php?ator='. $resultado['id_ator']. '">               editar</a>';
			echo '</a>';
			echo '<br>';

			echo '<a href="ator_delete.php?ator='. $resultado['id_ator']. '"> eliminar</a>';
			echo'<br>';



		}
	$stm->close();
	?>

<br>
<hr>
<a href="filmes_create.php">Filmes Create</a><br>
<a href="ator_create.php">Atores Create</a>

	</body>
	</html>

<?php
	} //end if - if($con->connect_errno!=0)
}//session

else {
	echo "Para entrar nesta página necessita de efetuar <a href='login.php'>login</a>";
		header ('refresh: 2; url=login.php');
}

?>


	
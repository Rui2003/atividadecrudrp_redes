<?php
if ($_SERVER['REQUEST_METHOD']=="GET") {
	if (isset($_GET['ator'])&& is_numeric($_GET['ator'])) {
		$idAtor=$_GET['ator'];
		$con=new mysqli("localhost","root","","filmes");

	if ($con->connect_errno!=0) {
		echo "<h1>Ocorreu um erro no acesso a base de dados.<br>".$connect_eror."</h1>";
		exit;
}
else {
	$sql="delete from atores where id_Ator=?";
	$stm=$con->prepare($sql);
	if ($stm!=false) {
		$stm->bind_param("i",$idAtor);
		$stm->execute();
		$stm->close();
	echo '<script>alert("Ator eliminado com sucesso");</script>';
	echo 'Aguarde um momento.A reencaminhar página';
	header("refresh:2; url=index.php");
	}
		else{
		echo '<br>';
		echo ($con->error);
		echo '<br>';
		echo "Aguarde um momento.A reencaminhar página";
		echo '<br>';
		header("refresh:2; url=index.php");
		}
	}
}
else {
	echo "<h1>houve um erro ao precessar o seu pedido.<br> Dentro de segundos será reencaminhado!</h1>";
	header("refresh:2; url=index.php");
	}
}
else {
	echo "<h1>houve um erro ao precessar o seu pedido.<br> Dentro de segundos será reencaminhado!</h1>";
	header("refresh:2; url=index.php");
}



?>



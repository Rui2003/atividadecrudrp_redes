<?php

if($_SERVER['REQUEST_METHOD']=="POST"){
	$nome="";
	$nacionalidade="";
	$datanascimento="";

	if(isset($_POST['nome'])){
		$titulo = $_POST['nome'];
	}
	else {
		echo '<script>alert("É obrigatório o preenchimento do nome.");</script>';
	}
	if(isset($_POST['nacionalidade'])) {
		$sinopse = $_POST['nacionalidade'];
	}
	if(isset($_POST['datanascimento'])) {
	$data_lancamento = $_POST['datanascimento'];
}
$con =new mysqli("localhost", "root", "", "filmes");

if($con->connect_errno!=0){
	echo "Ocorreu um erro no acesso á base de dados. <br> ". $con->connect_error;
	exit;
}

else {

$sql = 'insert into atores (nome, nacionalidade, datanascimento) values (?,?,?)';
$stm = $con->prepare ($sql);
if ($stm!=false) {

	$stm->bind_param('sss', $nome, $nacionalidade, $datanascimento);
	$stm->execute();
	$stm->close();

	echo '<script>alert("Livro adicionado com sucesso");</script>';
	echo 'Aguarde um momento. A reencaminhar página';
	header("refresh:5; url = index.php");

		}	
else {
	echo($con->error);
	echo "Aguarde um momento. A reencaminhar página";
	header("refresh:5; url = index.php");
		}
	} //end if - if($con->connect_errno!=0)
} //if($_SERVER['REQUEST_METHOD']=="POST")
else { // else if($_SERVER['REQUEST_METHOD']=="POST")

?>


<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
	<title>Adicionar atores</title>
</head>
<body>
<h1>Adicionar atores</h1>
<form action="ator_create.php" method="post">
<label>Nome</label><input type="text" name="nome" required><br>
<label>Nacionalidade</label><input type="text" name="nacionalidade"><br>
<label>Data de nascimento</label><input type="date" name="datanascimento"><br>
<input type="submit" name="enviar"><br>
</form>
</body>
</html>

<?php
	} //end if - if($_SERVER['REQUEST_METHOD']=="POST")
?>




